<ul class='nav nav-stacked'>
<li class=''>
    <a href="index.php">
        <i class='icon-home'></i>
        <span>Beranda</span>
    </a>
</li>

<li class=''>
    <a class='dropdown-collapse' href='#'>
        <i class='icon-folder-open-alt'></i>
        <span>MASTER DATA</span>
        <i class='icon-angle-down angle-down'></i>
    </a>
    <ul class='nav nav-stacked'>
        <li class=''>
            <a href="pegawai.php">
                <i class='icon-user'></i>
                <span>Data Pegawai</span>
            </a>
        </li>
        <li class=''>
            <a href="kriteria.php">
                <i class='icon-user-md'></i>
                <span>Data Kriteria</span>
            </a>
        </li>
        <li class=''>
            <a href="bobot.php">
                <i class='icon-external-link-sign'></i>
                <span>Data Pembobotan</span>
            </a>
        </li>
    </ul>
</li>

<li>
    <a class='dropdown-collapse ' href='#'>
        <i class='icon-sitemap'></i>
        <span>DATA KLASIFIKASI</span>
        <i class='icon-angle-down angle-down'></i>
    </a>
    <ul class='nav nav-stacked'>
        <li class=''>
            <a href="himpunan.php">
                <i class='icon-external-link'></i>
                <span>Data Himpunan Kriteria</span>
            </a>
        </li>
       <li class=''>
            <a href="klasifikasi.php">
                <i class='icon-edit'></i>
                <span>Proses Klasifikasi</span>
            </a>
        </li>
        <li class=''>
            <a href="analisa.php">
                <i class='icon-bar-chart'></i>
                <span>Analisa</span>
            </a>
        </li>
    </ul>
</li>