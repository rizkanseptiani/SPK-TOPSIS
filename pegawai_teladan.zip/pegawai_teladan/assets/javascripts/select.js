$(document).ready (function() {
